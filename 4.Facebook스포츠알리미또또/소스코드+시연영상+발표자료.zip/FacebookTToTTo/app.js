'use strict';

const apiai = require('apiai');
const config = require('./config');
const express = require('express');
const bodyParser = require('body-parser');
const request = require('request');
const app = express();
const uuid = require('uuid');
const fs = require('fs');
var jimp = require('jimp');
var googledrive = require('./google-drive-api.js');

googledrive.init();

var vsimage;
jimp.read('resource/vs.png', function (err, image) {
  image.resize(32, 32);
  vsimage = image;
})

var schedule = require('node-schedule'),
  crawling = require('./crawling.js'),
  db = require('./db.js');

var chatBotDataInit = false;

var greetings = [
  ['새벽에 뭐하는 거야?'],
  ['아침은 먹었어?'],
  ['점심은 먹었어?'],
  ['저녁은 먹었어?']];
var botName = '또또'

if (!config.FB_PAGE_TOKEN) {
  throw new Error('missing FB_PAGE_TOKEN');
}
if (!config.FB_VERIFY_TOKEN) {
  throw new Error('missing FB_VERIFY_TOKEN');
}
if (!config.API_AI_CLIENT_ACCESS_TOKEN) {
  throw new Error('missing API_AI_CLIENT_ACCESS_TOKEN');
}

app.set('port', (process.env.PORT || 80))

app.use(express.static('public'));

app.use(bodyParser.urlencoded({
  extended: false
}))

app.use(bodyParser.json())

const apiAiService = apiai(config.API_AI_CLIENT_ACCESS_TOKEN, {
  language: "en"
});
const sessionIds = new Map();

app.get('/', function (req, res) {
  res.send('Hello world, I am a chat bot')
})

app.get('/webhook/', function (req, res) {
  console.log("request");
  if (req.query['hub.mode'] === 'subscribe' && req.query['hub.verify_token'] === config.FB_VERIFY_TOKEN) {
    res.status(200).send(req.query['hub.challenge']);
  } else {
    console.error("Failed validation. Make sure the validation tokens match.");
    res.sendStatus(403);
  }
})

app.post('/webhook', function (req, res) {
  var data = req.body;
  console.log("Webhook received :: " + data);

  if (data.object === 'page') {

    data.entry.forEach(function (entry) {
      var pageID = entry.id;
      var timeOfEvent = entry.time;

      entry.messaging.forEach(function (event) {
        if (event.message) {
          receivedMessage(event);
        } else {
          console.log("Webhook received unknown event: ", event);
        }
      });
    });
    res.sendStatus(200);
  }
});

function receivedMessage(event) {
  var senderID = event.sender.id;
  var recipientID = event.recipient.id;
  var timeOfMessage = event.timestamp;
  var message = event.message;

  if (!sessionIds.has(senderID)) {
    sessionIds.set(senderID, uuid.v1());
  }

  console.log("Received message for user %d and page %d at %d with message:",
    senderID, recipientID, timeOfMessage);
  console.log(JSON.stringify(message));

  sendTypingMessage(senderID, true);

  var messageId = message.mid;

  var messageText = message.text;
  var messageAttachments = message.attachments;

  console.log(messageText);

  if (messageText) {
    sendToApiAi(senderID, messageText);
  }
}

function sendToApiAi(sender, text) {
  var apiaiRequest = apiAiService.textRequest(text, {
    sessionId: sessionIds.get(sender),
    lang: 'en'
  });

  apiaiRequest.on('response', (response) => {
    handleApiAiResponse(sender, response);
  });

  apiaiRequest.on('error', (error) => console.error(error));
  apiaiRequest.end();
}

function handleApiAiResponse(sender, response) {
  var responseText = response.result.fulfillment.speech;
  var messages = response.result.fulfillment.messages;
  var action = response.result.action;
  var contexts = response.result.contexts;
  var parameters = response.result.parameters;
  var actionIncompleted = response.result.actionIncomplete;

  if (actionIncompleted) sendTextMessage(sender, responseText);
  else {
    switch (action) {
      case "schedule":
        var date = new Date();
        var queryData = {};

        queryData["teamA"] = parameters.teamName[0];
        queryData["teamB"] = parameters.teamName[1];

        if (parameters.date != "") {
          var day1 = parameters.date.split("-");
          queryData["month"] = day1[1];
          queryData["day"] = day1[2];
        }
        else if (parameters.dateperiod != "") {
          var dateData = parameters.dateperiod.split("/");
          day1 = dateData[0].split("-");
          var day2 = dateData[1].split("-");
          queryData["month"] = [day1[1], day2[1]];
          queryData["day"] = [day1[2], day2[2]];
        } else {
          queryData["month"] = date.getMonth() + 1;
          queryData["day"] = [date.getDate() - 1, date.getDate() + 1];
        }

        db.find(queryData, function (docs) {
          var count = docs.length;
          var resultMsg = "";
          if (docs.length == 0) {
            resultMsg = "자료가 없어... 다른 거 물어봐";
            sendTextMessage(sender,resultMsg);
          }
          else {
            sendSportMessage(sender, docs);
          }
        });
        break;
      default:
        sendTextMessage(sender, responseText);
    }
  }
}

function sendQuickReply(recipientId, text, replies, metadata) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      text: text,
      metadata: isDefined(metadata) ? metadata : '',
      quick_replies: replies
    }
  };
  callSendAPI(messageData);
}

function sendTypingMessage(recipientId, onOffFlag) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    sender_action: (onOffFlag) ? "typing_on" : "typing_off"
  };
  callSendAPI(messageData);
}

function sendSportMessage(recipientId, messageText) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      attachment: {
        type: "template",
        payload: {
          template_type: "generic",
          elements: []
        }
      }
    }
  }
  var allpromise = [];
  var count = 0;
  var maxcount = messageText.length;
  if(maxcount>20)maxcount = 20;
  messageText.forEach(function (data,index) {
    var images = [data.lImage, data.rImage];
    var jimps = [];
    jimps[0] = jimp.read(images[0]);
    jimps[1] = jimp.read(images[1]);
    var promise = Promise.all(jimps).then(function (parm) {
      console.log("start");
      var image = new jimp(200, 100, 0xffffffff);
      parm[0].resize(64, 64);
      parm[1].resize(64, 64);
      image.composite(parm[0], 18, 30)
        .composite(parm[1], 118, 30)
        .composite(vsimage, 82, 52);
      image.write('resource/' + data.month + '' + data.day + '' + data.lTeam + '' + data.rTeam + '.png', function () {
        googledrive.uploadImage(data.month + '' + data.day + '' + data.lTeam + '' + data.rTeam, function (id) {
          messageData.message.attachment.payload.elements[index] = {
            "title": data.lTeam + ' 과 ' + data.rTeam + '의 경기'+((data.rScore!=null)?'가 있습니다.':' 결과입니다.'),
            "subtitle": ((data.rScore!=null)?'경기가 '+ data.month+'-'+data.day+ '일 '+data.hour+':'+data.minute+'시 에 있습니다.': data.lScore+'  :  '+data.rScore),
            "image_url": "https://drive.google.com/uc?id=" + id
          }
          count++;
          if (maxcount == count)
            callSendAPI(messageData);
        });
      });
    });
    allpromise.push(promise);
  }, this);
  Promise.all(allpromise);
}

function sendTextMessage(recipientId, messageText) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      text: messageText
    }
  };
  callSendAPI(messageData);
}

function callSendAPI(messageData) {
  request({
    uri: 'https://graph.facebook.com/v2.6/me/messages',
    qs: { access_token: config.FB_PAGE_TOKEN },
    method: 'POST',
    json: messageData

  }, function (error, response, body) {
    if (!error && response.statusCode == 500) {
      var recipientId = body.recipient_id;
      var messageId = body.message_id;

      console.log("Successfully sent generic message with id %s to recipient %s",
        messageId, recipientId);
    } else {
      console.error("Unable to send message.");
      console.error(response);
      console.error(error);
    }
  });
}

function isDefined(obj) {
  if (typeof obj == 'undefined') {
    return false;
  }

  if (!obj) {
    return false;
  }

  return obj != null;
}

app.listen(app.get('port'), function () {
  console.log('running on port', app.get('port'))
})

var UpdateRule = new schedule.RecurrenceRule();
UpdateRule.minute = [10];

db.getDataSize(function (size) {
  if (size == 0) {
    crawling.updateCrawlingData(function () {
      db.insert(crawling.getData());
      crawling.clearData();
      chatBotDataInit = true;
    }, true)
  }
});

schedule.scheduleJob(UpdateRule, function () {
  if (chatBotDataInit == true) {
    crawling.updateCrawlingData(function () {
      db.insert(crawling.getData());
      crawling.clearData();
    }, false);
  }
});
