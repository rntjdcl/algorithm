var cheerio = require('cheerio');
var phantom = require('phantom');
var db = require('./db.js');
function sportData() {
    var month;
    var day;
    var hour;
    var minute;
    var place;
    var lTeam;
    var lScore;
    var rTeam;
    var rScore;
    var rImage;
    var lImage;
}

var data = [];

var count = 0;
module.exports = {
    getData: (function () {
        return data;
    }),
    clearData: (function () {
        data = [];
    }),
    updateCrawlingData: (function (callback, firstInit) {      
        setTimeout((function () {
            getData('football','http://sports.news.naver.com/kfootball/schedule/index.nhn', getDataFormat1, true, firstInit);
        }), ((firstInit == true) ? 0 : 0));
        setTimeout((function () {
            getData('football','http://sports.news.naver.com/wfootball/schedule/index.nhn', getDataFormat1, true, firstInit);
        }), ((firstInit == true) ? 50000 : 10000));
        setTimeout((function () {
            getData('baseball','http://sports.news.naver.com/wbaseball/schedule/index.nhn', getDataFormat1, true, firstInit);
        }), ((firstInit == true) ? 150000 : 20000));
        setTimeout((function () {
            getData('baseball','http://sports.news.naver.com/kbaseball/schedule/index.nhn', getDataFormat2, false, false);
        }), ((firstInit == true) ? 250000 : 30000));
        setTimeout(callback, ((firstInit == true) ? 300000 : 40000));
    })
}

function getData(desc, url, callback, loopFlag, monthLoopFlag) {
    var phInstance, sitepage;
    phantom.create().then((instance) => {
        phInstance = instance;
        return instance.createPage();
    }).then((page) => {
        sitepage = page;
        return page.open(url);
    }).then((status) => {
        console.log(status);
        return sitepage.property('content');
    }).then((body) => {
        var $ = cheerio.load(body);
        if (monthLoopFlag == true) {
            if ($('#_yearMonthList').length != 0) {
                $('#_yearMonthList').find('li').each(function (idx) {
                    if (!$(this).hasClass('selected')) {
                        var yearMonth = $(this).attr('data-yearmonth');
                        var str;
                        if (loopFlag == true)
                            str = '&year=' + yearMonth.slice(0, 4);
                        else
                            str = '?year=' + yearMonth.slice(0, 4);
                        str += '&month=' + yearMonth.slice(4, 6);
                        setTimeout(function (str) {
                            getData(desc, url + str, callback, false, false);
                        }, 1000 * (idx - 1), str);
                    }
                })
            }
        }
        callback($, desc,url);
        if (loopFlag == true) {
            $('#_categoryList').find('li').each(function (idx) {
                if (!$(this).hasClass('selected')) {
                    var categoryItem = $(this).find('a').attr('data-category');
                    if (categoryItem != null) {
                        setTimeout(function (categoryItem) {
                            getData(desc, url + '?category=' + categoryItem, callback, false, monthLoopFlag);
                        }, ((monthLoopFlag == true) ? 10000 * (idx - 1) : 0), categoryItem);
                    }
                }
            })
        }
        sitepage.close().then(() => {
            phInstance.exit();
        })
    }).catch((error) => {
        console.log(error);
        phInstance.exit();
    });
}

var getDataFormat1 = function (_$,desc, url) {
    var $ = _$;
    var scheduleBoard = $('#_monthlyScheduleList').find('tr');
    var month, day;
    scheduleBoard.each(function () {
        if ($(this).find('em').length != 0) {
            var date = $(this).find('em').text().split(['.']);
            month = date[0];
            day = date[1];
        }
        if ($(this).find('.empty').length == 0) {
            var temp = new Array(1);
            temp.sport = desc;
            temp.month = month;
            temp.day = day;
            var time = $(this).find('.time').text().split([':'])
            temp.hour = time[0];
            temp.minute = time[1];
            temp.place = $(this).find('.place').text();
            temp.lTeam = $(this).find('.team_left .name').text();
            temp.rTeam = $(this).find('.team_right .name').text();
            temp.rImage = $(this).find('.team_right').find('img').attr('src');
            temp.lImage = $(this).find('.team_left').find('img').attr('src');
            temp.lScore = $(this).find('.team_left .score').text();
            temp.rScore = $(this).find('.team_right .score').text();
            data.push(temp);
        }
    });
    console.log(url);
};

var getDataFormat2 = function (_$, desc,url) {
    var $ = _$;
    var scheduleBoard = $('#calendarWrap').find('div');
    var month, day;
    scheduleBoard.each(function () {
        if ($(this).hasClass("nogame") == false && $(this).hasClass("nogame2") == false) {
            var date = $(this).find('.td_date').find('strong').text().split(['.']);
            month = date[0];
            day = date[1];
            $(this).find('tr').each(function () {
                var temp = new Array(1);
                temp.sport = desc;
                temp.month = month;
                temp.day = day;
                var time = $(this).find('.td_hour').text().split([':']);
                temp.hour = time[0];
                temp.minute = time[1];
                temp.place = $(this).find('.td_stadium').last().text();
                temp.lTeam = $(this).find('.team_lft').text();  
                temp.lImage = $(this).find('.team_lft').next().attr('src');
                temp.rImage = $(this).find('.team_rgt').prev().attr('src');
                temp.rTeam = $(this).find('.team_rgt').text();
                if ($(this).find('.td_score').find('.vs').length == 0) {
                    var score = $(this).find('.td_score').text().split([':']);
                    temp.lScore = score[0];
                    temp.rScore = score[1];
                }
                data.push(temp);
            });
        }
    });
    console.log(url);
};
