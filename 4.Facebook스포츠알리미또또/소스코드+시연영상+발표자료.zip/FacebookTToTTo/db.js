var Client = require('mongodb').MongoClient;

module.exports = {
    getDataSize: (function (callback) {
        Client.connect('mongodb://localhost:27017/db', function (error, db) {
            if (error) console.log(error);
            else {
                db.collection('SportPlay1').count(function (err, count) {
                    callback(count);
                });
            }
        });
    }),

    insert: (function (_data) {
        var data = _data;
        Client.connect('mongodb://localhost:27017/db', function (error, db) {
            if (error) console.log(error);
            else {
                console.log("connected");
                data.forEach(function(data) {
                    var updatequery = {
                        sport: data.sport, month: parseInt(data.month), day: parseInt(data.day), hour: parseInt(data.hour), minute: parseInt(data.minute), place: data.place
                        , lTeam: data.lTeam, lScore: parseInt(data.lScore), rTeam: data.rTeam, rScore: parseInt(data.rScore), rImage : data.rImage,lImage:data.lImage
                    };
                    var query = {
                        sport: data.sport, month: parseInt(data.month), day: parseInt(data.day), hour: parseInt(data.hour), minute: parseInt(data.minute), place: data.place
                        , lTeam: data.lTeam, lScore: parseInt(data.lScore), rTeam: data.rTeam, rScore: parseInt(data.rScore), rImage : data.rImage,lImage:data.lImage
                    };
                    db.collection('SportPlay1').update(query, updatequery, { upsert: true }, function (err, upserted) {
                        if (err) console.log(err);
                    });
                }, this);
            }
        });
    }),

    getData: (function (queryData, callback) {
        Client.connect('mongodb://localhost:27017/db', function (error, db) {
            if (error) console.log(error);
            else {
                var projection = { _id: 0 };
                for (var i = 0; i < queryData.length; i++) {
                    projection[queryData[i]] = 1;
                }
                var pro = Object(projection);
                db.collection('SportPlay1').find({}, projection).toArray(function (err, docs) {
                    if (err) console.log(err);
                    else callback(docs);
                    db.close();
                });
            }
        })
    }),

    find: (function (queryData, callback) {
        Client.connect('mongodb://localhost:27017/db', function (error, db) {
            if (error) console.log(error);
            else {
                console.log("connected:" + db);
                var query = {};
                if (queryData.teamA != undefined && queryData.teamB != undefined) {
                    query = { $or: [{ rTeam: queryData.teamA, lTeam: queryData.teamB }, { rTeam: queryData.teamB, lTeam: queryData.teamA }] };
                } else if (queryData.teamA != undefined || queryData.teamB != undefined) {
                    query = { $or: [{ $or: [{ rTeam: queryData.teamA }, { lTeam: queryData.teamA }] }, { $or: [{ rTeam: queryData.teamB }, { lTeam: queryData.teamB }] }] };
                }
                queryData["teamA"] = undefined;
                queryData["teamB"] = undefined;

                if (queryData['month'] != undefined) {
                    if (typeof(queryData['month'])== typeof([])) {
                        query['month'] = { $gte: parseInt(queryData['month'][0]), $lte: parseInt(queryData['month'][1]) };
                    } else {
                        query['month'] = parseInt(queryData['month']);
                    }
                }

                if (queryData['day'] != undefined) {
                    if (typeof(queryData['day'])== typeof([])) {
                        if (typeof(queryData['month'])== typeof([])) {
                            if (parseInt(queryData['month'][0]) != parseInt(queryData['month'][1])) {
                                if (query["$or"] == undefined)
                                    query["$or"] = [];
                                query["$or"].push({ day: [{ $gte: parseInt(queryData['day'][0]) }, { $lte: parseInt(queryData['day'][1]) }] });
                            }
                            else
                                query['day'] = { $gte: parseInt(queryData['day'][0]), $lte: parseInt(queryData['day'][1]) };
                        }
                        else query['day'] = { $gte: parseInt(queryData['day'][0]), $lte: parseInt(queryData['day'][1]) };
                    } else {
                        query['day'] = parseInt(queryData['day']);
                    }
                    queryData["day"] = undefined;
                }

                queryData["month"] = undefined;

                for (var key in queryData) {
                    if (queryData[key] != undefined) {
                        if (!isNaN(parseInt(queryData[key])))
                            query[key] = parseInt(queryData[key]);
                        else
                            query[key] = queryData[key];
                    }
                }
                var msg = [];
                db.collection('SportPlay1').find(query).sort({ month: 1, day: 1 ,hour:1, minute:1}).toArray(function (err, docs) {
                    if (err) console.log(err);
                    else callback(docs);
                    db.close();
                });
            }
        })
    })
}
