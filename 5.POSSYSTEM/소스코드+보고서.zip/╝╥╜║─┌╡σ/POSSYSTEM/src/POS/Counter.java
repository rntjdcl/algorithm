package POS;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Counter extends JPanel{
	
	
	JButton Order=new JButton("�ֹ��ϱ�");
	JButton Check_out=new JButton("Check Out");
	Order_Counter order_Counter=new Order_Counter();
	Checkout_Counter checkout_Counter=new Checkout_Counter();

	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(new Color(170, 170, 255));
		g.drawRect(0, 0, 359, 350);
	}
	
	public Counter()
	{
		
		setSize(360,500);
		setBackground(Color.white);
		
		setLayout(null);
		Order.setBackground(Color.white);
		Order.setForeground(Color.black);
		Order.setSize(180,50);
		Order.setLocation(0, 0);
		Order.setFont(new Font("Helvetica",Font.BOLD,15));
		Check_out.setBackground(Color.white);
		Check_out.setForeground(Color.black);
		Check_out.setSize(180,50);
		Check_out.setLocation(180, 0);
		Check_out.setFont(new Font("Helvetica",Font.BOLD,15));

		add(Order);
		add(Check_out);

		order_Counter.setLocation(0,50);
		add(order_Counter);
		checkout_Counter.setLocation(0,50);
		add(checkout_Counter);


		//�ֹ� ��ư ���Ǹ�����
		Order.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				checkout_Counter.setVisible(false);
				order_Counter.setVisible(true);
		}
		});
		
		//��� ��ư �׼Ǹ�����
		Check_out.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				
				order_Counter.setVisible(false);
				checkout_Counter.setVisible(true);
		}
		});
	}
	

	
	
	class Order_Counter extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 359, 350);
			
		}
		public Order_Counter()
		{
			setSize(360,450);
			setBackground(Color.white);
			setLayout(null);
			setVisible(false);
			
			JLabel TableNum =new JLabel("���̺���ȣ  :");
			TableNum.setForeground(Color.black);
			TableNum.setVisible(true);
			TableNum.setSize(120,40);
			TableNum.setFont(new Font("Helvetica",Font.BOLD,18));
			TableNum.setLocation(5,0);
			add(TableNum);
			
			
			JLabel Menu =new JLabel("    ��     ��    : ");
			Menu.setForeground(Color.black);
			Menu.setSize(120,40);
			Menu.setFont(new Font("Helvetica",Font.BOLD,18));
			Menu.setLocation(5,45);
			add(Menu);
			
			
			JLabel Count =new JLabel("    ��     ��    : ");
			Count.setForeground(Color.black);
			Count.setVisible(true);
			Count.setSize(120,40);
			Count.setFont(new Font("Helvetica",Font.BOLD,18));
			Count.setLocation(5,90);
			add(Count);
			
			//���̺���ȣ �����ϴ� �޺��ڽ�
			String[] tables={"1","2","3","4","5","6","7","8","9"};
			
			JComboBox tablelist=new JComboBox(tables);
			tablelist.setSize(100,20);
			tablelist.setLocation(135,12);
			tablelist.setForeground(Color.black);
			tablelist.setVisible(true);
			add(tablelist);
			
			
			//�޴������ϴ� �޺��ڽ�
			String Menus []=new String[MAIN.menuamount];
			for(int i=0;i<MAIN.menuamount;i++)
			{
				Menus[i]=MAIN.food[i].food_name;
			}
			JComboBox menulist=new JComboBox(Menus);
			menulist.setSize(100,20);
			menulist.setLocation(135,56);
			menulist.setForeground(Color.black);
			menulist.setVisible(true);
			menulist.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e)
				{
					JComboBox cb=(JComboBox)e.getSource();
					
					int index=cb.getSelectedIndex();
					
				}
			});
			add(menulist);
			
			//�����Է��ϴ� �ؽ�Ʈ�ʵ�
			JTextField countfield=new JTextField("1");
			countfield.setSize(40,20);
			countfield.setLocation(135,101);
			countfield.setVisible(true);
			countfield.setBackground(Color.white);
			countfield.setForeground(Color.black);
			add(countfield);
			
			//�޴��߰���ư
			JButton Add=new JButton("��     ��");
			Add.setSize(100,30);
			Add.setVisible(true);
			Add.setBackground(Color.white);
			Add.setForeground(Color.black);
			Add.setLocation(55,150);
			Add.setFont(new Font("Helvetica",Font.BOLD,13));
			add(Add);
			Add.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					int Tableindex=tablelist.getSelectedIndex();
					int Menuindex=menulist.getSelectedIndex();

					
					int order_count=Integer.parseInt(countfield.getText());
					
					boolean last=false;
					
					if(order_count-MAIN.food[Menuindex].food_stock==0)
					{
						last=true;
					}
					int temp=MAIN.food[Menuindex].food_stock;
					MAIN.food[Menuindex].food_stock-=order_count;
					
					
					if(last==true|| MAIN.food[Menuindex].food_stock>0){
					User.t[Tableindex].TM[Menuindex].ordered=true;
					User.t[Tableindex].TM[Menuindex].menulabel.setVisible(true);
					User.t[Tableindex].TM[Menuindex].table_count+=order_count;
					User.t[Tableindex].TM[Menuindex].table_price+=MAIN.food[Menuindex].food_price*order_count;
					User.t[Tableindex].TM[Menuindex].menulabel.setText(MAIN.food[Menuindex].food_name+" "+Integer.toString(User.t[Tableindex].TM[Menuindex].table_count)+"�� "+Integer.toString(User.t[Tableindex].TM[Menuindex].table_price));
					User.t[Tableindex].TM[Menuindex].menulabel.setForeground(Color.white);
					User.t[Tableindex].order_infor.add(User.t[Tableindex].TM[Menuindex].menulabel);
					
					User.t[Tableindex].money+=MAIN.food[Menuindex].food_price*order_count;
					User.t[Tableindex].Allmoney.setText("�� �ݾ� : "+Integer.toString(User.t[Tableindex].money)+"��");
					User.t[Tableindex].Allmoney.setVisible(true);
					}
					else{
						 JOptionPane.showMessageDialog(null,User.t[Tableindex].TM[Menuindex].table_name+"����� �ٶ��������ϴ�!","",JOptionPane.ERROR_MESSAGE);
						 
						 
						 if(temp<order_count)
						 {
							 MAIN.food[Menuindex].food_stock=temp;
						 }
						 else{
							 MAIN.food[Menuindex].food_stock=0;
						 }
					}
				}
			});
			
			//�޴�������ư
			JButton Delete=new JButton("��     ��");
			Delete.setSize(100,30);
			Delete.setVisible(true);
			Delete.setBackground(Color.white);
			Delete.setForeground(Color.black);
			Delete.setLocation(200,150);
			Delete.setFont(new Font("Helvetica",Font.BOLD,13));
			add(Delete);
			Delete.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					int Tableindex=tablelist.getSelectedIndex();
					int Menuindex=menulist.getSelectedIndex();
					int count=Integer.parseInt(countfield.getText());
					
					int order_count=Integer.parseInt(countfield.getText());
				
					if(User.t[Tableindex].TM[Menuindex].table_count>0){
					User.t[Tableindex].TM[Menuindex].table_count-=order_count;
					User.t[Tableindex].TM[Menuindex].table_price-=MAIN.food[Menuindex].food_price*order_count;
					User.t[Tableindex].money-=MAIN.food[Menuindex].food_price*count;
					User.t[Tableindex].TM[Menuindex].menulabel.setText(MAIN.food[Menuindex].food_name+" "+Integer.toString(User.t[Tableindex].TM[Menuindex].table_count)+"�� "+Integer.toString(User.t[Tableindex].TM[Menuindex].table_price));
					MAIN.food[Menuindex].food_stock+=order_count;
				}
					if(User.t[Tableindex].TM[Menuindex].table_count==0)
					{
						User.t[Tableindex].TM[Menuindex].ordered=false;
						User.t[Tableindex].TM[Menuindex].menulabel.setVisible(false);
					}
					
					if(User.t[Tableindex].money>0&&User.t[Tableindex].TM[Menuindex].table_count!=0){
						
						if(User.t[Tableindex].money<0)
						{
							User.t[Tableindex].money=0;
						}
					}
					
					User.t[Tableindex].Allmoney.setText("�� �ݾ� : "+Integer.toString(User.t[Tableindex].money)+"��");
					
					boolean empty=false;
					for(int k=0;k<8;k++)
					{
						if(User.t[Tableindex].TM[k].ordered==true)
						{
							 empty=true;
						}
						
					}
					if(empty==false)
					{
						User.t[Tableindex].Allmoney.setVisible(false);
					}
				}
			});
		}
	}

	class Checkout_Counter extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 359, 350);

		}
		public Checkout_Counter()
		{
			setSize(360,450);
			setBackground(Color.white);
			setLayout(null);
			setVisible(false);
			
			JLabel TableNum =new JLabel("���̺���ȣ  :");
			TableNum.setForeground(Color.black);
			TableNum.setVisible(true);
			TableNum.setSize(120,40);
			TableNum.setFont(new Font("Helvetica",Font.BOLD,18));
			TableNum.setLocation(5,0);
			add(TableNum);
			
			
			String[] tables={"1","2","3","4","5","6","7","8","9"};
			JComboBox tablelist=new JComboBox(tables);
			tablelist.setSize(100,20);
			tablelist.setLocation(135,12);
			tablelist.setForeground(Color.black);
			tablelist.setVisible(true);
			add(tablelist);
			
			ButtonGroup g=new ButtonGroup(); //��ư �׷�
			
			//��ư����
			JRadioButton cash=new JRadioButton("��  ��",true);
			JRadioButton card=new JRadioButton("ī  ��");
			g.add(cash);
			g.add(card);
			
			cash.setVisible(true);
			cash.setSize(100,50);
			cash.setLocation(80, 50);
			cash.setForeground(Color.black);
			cash.setBackground(Color.white);
			cash.setFont(new Font("Helvetica",Font.BOLD,15));
			add(cash);
			
			card.setVisible(true);
			card.setSize(100,50);
			card.setLocation(215, 50);
			card.setForeground(Color.black);
			card.setBackground(Color.white);
			card.setFont(new Font("Helvetica",Font.BOLD,15));
			add(card);
			
			//����ϱ� ��ư
			JButton checkout=new JButton("�� �� �� ��");
			checkout.setSize(120,40);
			checkout.setVisible(true);
			checkout.setBackground(Color.black);
			checkout.setForeground(Color.white);
			checkout.setLocation(120,110);
			checkout.setFont(new Font("Helvetica",Font.BOLD,13));
			add(checkout);
			
			//����ϱ� ��ư ���� �׼Ǹ�����
			
			class CheckoutListener implements ActionListener{
				public void actionPerformed(ActionEvent e){
					int Tableindex=tablelist.getSelectedIndex();
					int num = g.getButtonCount();
					 
					for(int i=0;i<8;i++)
					{
						if(User.t[Tableindex].TM[i].ordered==true)
						{			
							MAIN.food[i].food_sales+=User.t[Tableindex].TM[i].table_price;
						}
					}					
					MAIN.allsales+=User.t[Tableindex].money;					 


					if(User.t[Tableindex].money==0)
					{
						 
						JOptionPane.showMessageDialog(null,(Tableindex+1)+"�� ���̺��� �����̺��Դϴ�!!","",JOptionPane.ERROR_MESSAGE);
					}
					 else{
							if(cash.isSelected()==true)//����
							{
								JOptionPane.showMessageDialog(null, "�����ݾ��� "+Integer.toString(User.t[Tableindex].money)+"���Դϴ�","",JOptionPane.INFORMATION_MESSAGE);
								String inputmoney=JOptionPane.showInputDialog("���� �ݾ��� �Է��ϼ���");
								JOptionPane.showMessageDialog(null,"�Ž�������"+(Integer.parseInt(inputmoney)-(User.t[Tableindex].money))+"�Դϴ�.","",JOptionPane.INFORMATION_MESSAGE);					
							}
							else if(card.isSelected()==true)//ī��
							{
								JOptionPane.showMessageDialog(null, "�����ݾ��� "+Integer.toString(User.t[Tableindex].money)+"���Դϴ�","",JOptionPane.INFORMATION_MESSAGE);
								
							}
							int result=JOptionPane.showConfirmDialog(null, "�������� ����Ͻðڽ��ϱ�?","",JOptionPane.YES_NO_OPTION);
							if(result==JOptionPane.CLOSED_OPTION) //�׳� ������
							{
								for(int i=0;i<8;i++)
								{
									User.t[Tableindex].TM[i].ordered=false;
									User.t[Tableindex].TM[i].table_count=0;
									User.t[Tableindex].TM[i].table_price=0;					
									User.t[Tableindex].TM[i].menulabel.setText("");
									User.t[Tableindex].TM[i].menulabel.setVisible(false);
								}
								User.t[Tableindex].money=0;
								User.t[Tableindex].Allmoney.setVisible(false);
							}
							else if(result==JOptionPane.YES_OPTION)//������ ��½�
							{
								String str []={"��� �޴�+�Ѿ�","�Ѿ׸�"};
								int selected=JOptionPane.showOptionDialog(MAIN.mainFrame, "���ϴ� �������� �����ϼ���","������ ����", JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.INFORMATION_MESSAGE,null, str, str[0]);
								if(selected==JOptionPane.CLOSED_OPTION)
								{			
									for(int i=0;i<8;i++)
									{
										User.t[Tableindex].TM[i].ordered=false;
										User.t[Tableindex].TM[i].table_count=0;
										User.t[Tableindex].TM[i].table_price=0;			
										User.t[Tableindex].TM[i].menulabel.setText("");					
										User.t[Tableindex].TM[i].menulabel.setVisible(false);
									}
									User.t[Tableindex].money=0;
									User.t[Tableindex].Allmoney.setVisible(false);

								}
								else if(selected==JOptionPane.YES_OPTION)
								{

									String Show=(Tableindex+1)+"�� ���̺� \n";
									
									for(int i=0;i<8;i++)
									{
										if(User.t[Tableindex].TM[i].ordered==true)
										{
											Show+=User.t[Tableindex].TM[i].table_name+" "+(User.t[Tableindex].TM[i].table_count)+"��"+" = "+User.t[Tableindex].TM[i].table_price+"\n";
										}
									}
									
									Show+="�Ѿ� : "+(User.t[Tableindex].money);
									
									JOptionPane.showMessageDialog(null, Show,"",JOptionPane.INFORMATION_MESSAGE);
									
									
									for(int i=0;i<8;i++)
									{
										User.t[Tableindex].TM[i].ordered=false;
										User.t[Tableindex].TM[i].table_count=0;
										User.t[Tableindex].TM[i].table_price=0;
										
										User.t[Tableindex].TM[i].menulabel.setText("");
										
										User.t[Tableindex].TM[i].menulabel.setVisible(false);
									}
									User.t[Tableindex].money=0;
									User.t[Tableindex].Allmoney.setVisible(false);
								}
								else if(selected==JOptionPane.NO_OPTION){
									JOptionPane.showMessageDialog(null,(Tableindex+1)+ "�� ���̺� \n�Ѿ�  : "+(User.t[Tableindex].money),"",JOptionPane.INFORMATION_MESSAGE);
									for(int i=0;i<8;i++)
									{
										User.t[Tableindex].TM[i].ordered=false;
										User.t[Tableindex].TM[i].table_count=0;
										User.t[Tableindex].TM[i].table_price=0;
										
										User.t[Tableindex].TM[i].menulabel.setText("");
										
										User.t[Tableindex].TM[i].menulabel.setVisible(false);
									}
									User.t[Tableindex].money=0;
									User.t[Tableindex].Allmoney.setVisible(false);
								}
							}
							// ������ ��¾��ҽ�
							else if(result==JOptionPane.NO_OPTION){
								for(int i=0;i<8;i++)
								{
									User.t[Tableindex].TM[i].ordered=false;
									User.t[Tableindex].TM[i].table_count=0;
									User.t[Tableindex].TM[i].table_price=0;
									
									User.t[Tableindex].TM[i].menulabel.setText("");
									
									User.t[Tableindex].TM[i].menulabel.setVisible(false);	
								}
								User.t[Tableindex].money=0;
								User.t[Tableindex].Allmoney.setVisible(false);
							}
						}
					}}
					checkout.addActionListener(new CheckoutListener());	
			}
	}
}