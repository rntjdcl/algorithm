package POS;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Food {
	int food_num;
	String food_name;
	int food_price;
	int food_stock;
	int food_sales;
	static String[] store=new String[45]; //�޴� ����
	
	FileReader fin = null;
	BufferedReader in = null;
	StringTokenizer st = null;
	int index = 0;
	
	public Food(){
		food_num=0;
		food_name="null";
		food_price=0;
		food_stock=0;
		food_sales=0;
	}
	
	public Food(int num,String name,int price,int stock,int sale){
		food_num=num;
		food_name=name;
	    food_price=price;	
		food_num=stock;
		food_sales=sale;
	}
	public void print()
	{
		System.out.println(this.food_num+" "+this.food_name+" "+this.food_price+" "+this.food_stock+" "+this.food_sales);
	}
	
	public void set(int n){
			try{
				
				fin = new FileReader("C:\\Users\\Babo\\workspace\\POSSYSTEM\\posmenu.txt");	 
				in = new BufferedReader(fin);	 
				st = new StringTokenizer(in.readLine());

				while (st.hasMoreTokens())  //�޸��忡�� ���� �ϳ��� ���� �������� �о store�� ����
				 {
					 store[index]=st.nextToken();
					 ++index;
					 
				 }

				n=n*5;
				this.food_num= Integer.parseInt(store[n++]);
		    	this.food_name=store[n++];
		    	this.food_price= Integer.parseInt(store[n++]);
		    	this.food_stock= Integer.parseInt(store[n++]);
		    	this.food_sales= Integer.parseInt(store[n]);
				
			    
				in.close();
			    }
			    catch (FileNotFoundException e)
			    {
				    System.out.println("���� ����");
			    }
			    catch (IOException e){
				   System.out.println("error");
			   }    					
	}

}
