package POS;

public class MAIN {
	public static User mainFrame;
	
	public static int menuamount=User.getnum();
	public static Food [] food=new Food[menuamount];
	public static int allsales;
	
	public static void main(String[] arg){
		mainFrame=new User();
	}
}
