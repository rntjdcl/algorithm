package POS;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class Manager extends JFrame {
	
    ManagerPanel1 MP1=new ManagerPanel1();
	ManagerPanel2 MP2=new ManagerPanel2();
	ManagerPanel3 MP3=new ManagerPanel3();
	
	Manager(){

		Container c=getContentPane();
		c.setBackground(Color.BLACK);
		c.setLayout(null);
		setTitle("�����ڸ��");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(900,550);
		setVisible(false);
		
		JButton J1=new JButton("�޴�����");
		JButton J2=new JButton("�������");
		JButton J3=new JButton("����Ȯ��");
		J1.setFont(new Font("Helvetica",Font.BOLD,20));
		J2.setFont(new Font("Helvetica",Font.BOLD,20));
		J3.setFont(new Font("Helvetica",Font.BOLD,20));
		J1.setForeground(Color.white);
		J2.setForeground(Color.white);
		J3.setForeground(Color.white);
		J1.setBackground(Color.black);
		J2.setBackground(Color.black);
		J3.setBackground(Color.black);
		J1.setSize(220, 130);
		J2.setSize(220, 130);
		J3.setSize(220, 130);
		J1.setLocation(50, 365);
		J2.setLocation(335, 365);
		J3.setLocation(620, 365);
		c.add(J1);
		c.add(J2);
		c.add(J3);
		
		JButton showinven=new JButton("��� ��Ȳ");
		JButton addinven=new JButton("��� �߰�");
		
		showinven.setFont(new Font("Helvetica",Font.BOLD,14));
		addinven.setFont(new Font("Helvetica",Font.BOLD,14));
	
		showinven.setForeground(Color.white);
		addinven.setForeground(Color.white);
		
		showinven.setBackground(Color.black);
		addinven.setBackground(Color.black);

		showinven.setSize(200,50);
		addinven.setSize(200,50);

		showinven.setLocation(10,20);
		addinven.setLocation(10, 80);
		
		MP2.subinven.add(showinven);
		MP2.subinven.add(addinven);
		
		showinven.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				MP3.inventoryadd.setVisible(false);
				MP3.inventoryshow.setVisible(true);
				MP3.showallsales.setVisible(false);
				MP3.showmenusales.setVisible(false);
				MP3.pricechange.setVisible(false);
				MP3.menushow.setVisible(false);
			}
		});
		
		addinven.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				MP3.inventoryadd.setVisible(true);
				MP3.inventoryshow.setVisible(false);
				MP3.showallsales.setVisible(false);
				MP3.showmenusales.setVisible(false);
				MP3.pricechange.setVisible(false);
				MP3.menushow.setVisible(false);
			}
		});
		
		JButton showmenusales=new JButton("�޴��� ����");
		JButton showallsales=new JButton("�� ����");
		
		showmenusales.setFont(new Font("Helvetica",Font.BOLD,14));
		showallsales.setFont(new Font("Helvetica",Font.BOLD,14));
	
		showmenusales.setForeground(Color.white);
		showallsales.setForeground(Color.white);
		
		showmenusales.setBackground(Color.black);
		showallsales.setBackground(Color.black);

		showmenusales.setSize(200,50);
		showallsales.setSize(200,50);

		showmenusales.setLocation(10,20);
		showallsales.setLocation(10, 80);

		MP2.subsales.add(showmenusales);
		MP2.subsales.add(showallsales);
		
		showmenusales.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				MP3.inventoryadd.setVisible(false);
				MP3.inventoryshow.setVisible(false);
				MP3.showallsales.setVisible(false);
				MP3.showmenusales.setVisible(true);
				MP3.pricechange.setVisible(false);
				MP3.menushow.setVisible(false);
			}
		});
		
		showallsales.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				MP3.inventoryadd.setVisible(false);
				MP3.inventoryshow.setVisible(false);
				MP3.showallsales.setVisible(true);
				MP3.showmenusales.setVisible(false);
				MP3.pricechange.setVisible(false);
				MP3.menushow.setVisible(false);
			}
		});
		
		JButton showmenu=new JButton("�޴� ��Ȳ");
		JButton changeprice=new JButton("���� ����");
		
		showmenu.setFont(new Font("Helvetica",Font.BOLD,14));
		changeprice.setFont(new Font("Helvetica",Font.BOLD,14));
		
		showmenu.setForeground(Color.white);
		changeprice.setForeground(Color.white);
		
		showmenu.setBackground(Color.black);
		changeprice.setBackground(Color.black);
		
		showmenu.setSize(200,50);
		changeprice.setSize(200,50);
		
		showmenu.setLocation(10,20);
		changeprice.setLocation(10, 80);
		
		MP2.submenu.add(showmenu);
		MP2.submenu.add(changeprice);
		
		showmenu.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				MP3.inventoryadd.setVisible(false);
				MP3.inventoryshow.setVisible(false);
				MP3.showallsales.setVisible(false);
				MP3.showmenusales.setVisible(false);
				MP3.pricechange.setVisible(false);
				MP3.menushow.setVisible(true);
			}
		});
		
		changeprice.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				MP3.inventoryshow.setVisible(false);
				MP3.inventoryadd.setVisible(false);
				MP3.showmenusales.setVisible(false);
				MP3.showallsales.setVisible(false);
				MP3.menushow.setVisible(false);
				MP3.pricechange.setVisible(true);
			}
		});
		
		MP1.setLocation(50,30);
		c.add(MP1);
		
		MP2.setLocation(50,70);
		c.add(MP2);
		
		MP3.setLocation(270,70);
		c.add(MP3);
		J1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				
				MP2.subinven.setVisible(false);
				MP2.subsales.setVisible(false);
				MP2.submenu.setVisible(true);
			}
		});
		J2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				MP2.submenu.setVisible(false);
				MP2.subsales.setVisible(false);
				MP2.subinven.setVisible(true);	
			}
		});
		J3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JButton b=(JButton)e.getSource();
				
				MP2.submenu.setVisible(false);
				MP2.subinven.setVisible(false);
				MP2.subsales.setVisible(true);		
			}
		});
		this.addWindowListener(new WindowAdapter()
	    {
	      
	        public void windowClosing(WindowEvent e)
	        {
	        	MAIN.mainFrame.setVisible(true);        
	        }
	    });	
	}
}
class ManagerPanel1 extends JPanel{
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(new Color(170, 170, 255));
		g.drawRect(0, 0, 789, 39);	
	}
	public ManagerPanel1()
	{
		setSize(790,40);
		setBackground(Color.black);
		setLayout(new FlowLayout());
		JLabel name=new JLabel("��         ��         ��         ��         ��");
		name.setFont(new Font("Helvetica",Font.BOLD,19));
		name.setForeground(Color.white);
		name.setSize(500,40);
		add(name);
	}
}
class ManagerPanel2 extends JPanel{
	SubMenuManagement submenu=new SubMenuManagement();
	SubInventory subinven=new SubInventory();
	SubSales subsales=new SubSales();
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(new Color(170, 170, 255));
		g.drawRect(0, 0, 219, 269);
		
	}
	public ManagerPanel2()
	{
		setSize(220,270);
		setBackground(Color.black);
		setLayout(null);
		
		add(submenu);
		add(subinven);
		add(subsales);
	}
	class SubMenuManagement extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 219, 269);
		}
		public SubMenuManagement()
		{
			setSize(220,270);
			setBackground(Color.black);
			setLayout(null);
			setVisible(false);
		}
	}
	class SubInventory extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 219, 269);
		}
		 public SubInventory (){
			 setSize(220,270);
				setBackground(Color.black);
				setLayout(null);
				setVisible(false);
		 }
	}
	
	class SubSales extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 219, 269);
			
		}
		 public SubSales (){
			 setSize(220,270);
				setBackground(Color.black);
				setLayout(null);
				setVisible(false);	
		 }
	}
}
class ManagerPanel3 extends JPanel{
	MenuShow menushow=new MenuShow();
	PriceChange pricechange=new PriceChange();
	InventoryShow inventoryshow=new InventoryShow();
	InventoryAdd inventoryadd=new InventoryAdd();
	Showmenusales showmenusales =new Showmenusales();
	Showallsales showallsales=new Showallsales();
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(new Color(170, 170, 255));
		g.drawRect(0, 0, 569, 269);
	}
	public ManagerPanel3()
	{
		setSize(570,270);
		setBackground(Color.black);
		setLayout(null);
		
		add(menushow);
		add(pricechange);
		add(inventoryshow);
		add(inventoryadd);
		add(showmenusales);
		add(showallsales);
	}
	
	class MenuShow extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 569, 269);	
		}
		public MenuShow (){
			setBackground(Color.black);
			setLayout(new FlowLayout(FlowLayout.CENTER,500,5));
			setVisible(false);
			setSize(570,270);
    
			String s="";
			
			for(int i=0;i<MAIN.menuamount;i++)
			{
				s=MAIN.food[i].food_name+" "+Integer.toString(MAIN.food[i].food_price)+"��";
				
				JLabel show=new JLabel(s);
				show.setSize(570,30);
				show.setVisible(true);
				show.setForeground(Color.white);
				show.setBackground(Color.black);
				show.setFont(new Font("Helvetica",Font.BOLD,14));
				
				add(show);
			}	
		}
	}
	
	
	
	
	class PriceChange extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 569, 269);		
		}
		public PriceChange(){
			setBackground(Color.black);
			setLayout(null);
			setVisible(false);
			setSize(570,270);
			
			String Menus []=new String[MAIN.menuamount];
			for(int i=0;i<MAIN.menuamount;i++)
			{
				Menus[i]=MAIN.food[i].food_name;
			}
			JComboBox menulist=new JComboBox(Menus);
			menulist.setSize(100,20);
			menulist.setLocation(150,50);
			menulist.setForeground(Color.black);
			menulist.setVisible(true);
		
			add(menulist);
			
			JTextField countfield=new JTextField("0");
			countfield.setSize(40,20);
			countfield.setLocation(270,50);
			countfield.setVisible(true);
			countfield.setBackground(Color.black);
			countfield.setForeground(Color.white);
			add(countfield);
			
			JButton addin = new JButton("����");
			addin.setSize(60,20);
			addin.setLocation(330,50);
			addin.setVisible(true);
			addin.setBackground(Color.black);
			addin.setForeground(Color.white);
			add(addin);
			
			addin.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					JButton b=(JButton)e.getSource();
					
					int Menuindex=menulist.getSelectedIndex();
					int changed_price=Integer.parseInt(countfield.getText());
					
					MAIN.food[Menuindex].food_price=changed_price;
					MAIN.allsales-=MAIN.food[Menuindex].food_sales;
					MAIN.food[Menuindex].food_sales=0;
					
					JOptionPane.showMessageDialog(null,MAIN.food[Menuindex].food_name+"�� ������ "+Integer.toString(changed_price)+"�� �ٲ���ϴ�!!","",JOptionPane.INFORMATION_MESSAGE);}
			});
		}
	}
	class InventoryShow extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 569, 269);	
		}
		public InventoryShow(){
			setBackground(Color.black);
			setLayout(new FlowLayout(FlowLayout.CENTER,500,5));
			setVisible(false);
			setSize(570,270);
			
			String s="";
			
			for(int i=0;i<MAIN.menuamount;i++)
			{
				s=MAIN.food[i].food_name+" : "+MAIN.food[i].food_stock+"��";
				
				JLabel show=new JLabel(s);
				show.setSize(570,30);
				show.setVisible(true);
				show.setForeground(Color.white);
				show.setBackground(Color.black);
				show.setFont(new Font("Helvetica",Font.BOLD,14));
				
				add(show);
			}
		}
	}
	
	class InventoryAdd extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 569, 269);	
		}
		public InventoryAdd(){
			setBackground(Color.black);
			setLayout(null);
			setVisible(false);
			setSize(570,270);
			
			String Menus []=new String[MAIN.menuamount];
			for(int i=0;i<MAIN.menuamount;i++)
			{
				Menus[i]=MAIN.food[i].food_name;
			}
			JComboBox menulist=new JComboBox(Menus);
			menulist.setSize(100,20);
			menulist.setLocation(150,50);
			menulist.setForeground(Color.black);
			menulist.setVisible(true);
		
			add(menulist);
			
			JTextField countfield=new JTextField("1");
			countfield.setSize(40,20);
			countfield.setLocation(270,50);
			countfield.setVisible(true);
			countfield.setBackground(Color.black);
			countfield.setForeground(Color.white);
			add(countfield);
			
			JButton addin = new JButton("�߰�");
			addin.setSize(60,20);
			addin.setLocation(330,50);
			addin.setVisible(true);
			addin.setBackground(Color.black);
			addin.setForeground(Color.white);
			add(addin);
			
			addin.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					JButton b=(JButton)e.getSource();
					
					int Menuindex=menulist.getSelectedIndex();
					
					
					int order_count=Integer.parseInt(countfield.getText());
					MAIN.food[Menuindex].food_stock+=order_count;
					JOptionPane.showMessageDialog(null, MAIN.food[Menuindex].food_name+" "+Integer.toString(order_count)+"�� �߰� �߽��ϴ�!!","",JOptionPane.INFORMATION_MESSAGE);}
			});
		}
	}
	
	class Showmenusales extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 569, 269);	
		}
		public Showmenusales (){
			setBackground(Color.black);
			setLayout(new FlowLayout(FlowLayout.CENTER,500,5));
			setVisible(false);
			setSize(570,270);
			
			String s="";
			
			for(int i=0;i<MAIN.menuamount;i++)
			{
				s=MAIN.food[i].food_name+" : "+Integer.toString(MAIN.food[i].food_sales);
				
				JLabel show=new JLabel(s);
				show.setSize(570,30);
				show.setVisible(true);
				show.setForeground(Color.white);
				show.setBackground(Color.black);
				show.setFont(new Font("Helvetica",Font.BOLD,14));
				
				add(show);
			}
		}
	}
	
	class Showallsales extends JPanel{
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.setColor(new Color(170, 170, 255));
			g.drawRect(0, 0, 569, 269);	
		}
		public Showallsales (){
			setBackground(Color.black);
			setLayout(new FlowLayout(FlowLayout.CENTER,500,5));
			setVisible(false);
			setSize(570,270);
			
			String s="";
			
			s="�� �Ǹž� : "+Integer.toString(MAIN.allsales);
			
			JLabel show=new JLabel(s);
			show.setSize(570,30);
			show.setVisible(true);
			show.setForeground(Color.white);
			show.setBackground(Color.black);
			show.setFont(new Font("Helvetica",Font.BOLD,14));
			
			add(show);
			}
		}
	}
