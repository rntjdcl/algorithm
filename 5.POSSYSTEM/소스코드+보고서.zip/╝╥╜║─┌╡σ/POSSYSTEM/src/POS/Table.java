package POS;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Table extends JPanel{
	
	TablesMenu TM []=new TablesMenu[8];
	JLabel num;
	int money=0;
	
	JLabel Allmoney=new JLabel("�� �ݾ� : "+"0"+"��");
	Orderd_Infor order_infor=new Orderd_Infor();
	public Table(int n){
			JPanel Table=new JPanel();
			num=new JLabel("   "+n);
			num.setSize(40,15);
			num.setFont(new Font("Helvetica",Font.BOLD,20));
			num.setForeground(Color.white);
			add(num);

			
			order_infor.setLocation(5,44);
			order_infor.setVisible(true);
			
			add(order_infor);
		
			
			Allmoney.setSize(150,20);
			Allmoney.setFont(new Font("Helvetica",Font.BOLD,13));
			Allmoney.setForeground(Color.red);
			Allmoney.setVisible(false);
			add(Allmoney);
			
			
			}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(new Color(170, 170, 255));
		g.drawRect(0, 0, 279,159);
		
	}
}


class TablesMenu{
	
	String table_name;
	int table_count=0;
	int table_price=0;
	boolean ordered=false;
	String show=table_name+" "+Integer.toString(table_count)+" : "+Integer.toString(table_price*table_count);
	public TablesMenu(String name){
		this.table_name=name;
	}
	JLabel menulabel=new JLabel("");
}
class Orderd_Infor extends JPanel{
	public Orderd_Infor()
	{
		setSize(270,95);
		setBackground(Color.red);
		setLayout(new FlowLayout());
		setVisible(true);
}}
