package POS;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class User extends JFrame{
	
	public static Table [] t=new Table[9];
	
	User()
	{
		for(int j=0;j<MAIN.menuamount;j++)
		{
			MAIN.food[j]=new Food();
			MAIN.food[j].set(j);
			MAIN.food[j].print();
		}
		
		setTitle("�ݿ� ���� PosSystem");
		setSize(1800,1000);
		setVisible(true);
		
		Container c=getContentPane();
		c.setBackground(Color.white);
		c.setLayout(null);
		
		JLabel Restraunt_Name=new JLabel("��      ��      ��      ��");
		Restraunt_Name.setForeground(Color.black);
		Restraunt_Name.setSize(700,200);
		Restraunt_Name.setFont(new Font("Helvetica",Font.BOLD,71));
		Restraunt_Name.setLocation(480,-50);
		c.add(Restraunt_Name);
		
		Counter counter=new Counter();
		counter.setLocation(30,150);
		c.add(counter);
		
		JButton Managermode=new JButton("������ ���");
		Managermode.setSize(120,40);
		Managermode.setBackground(Color.red);
		Managermode.setForeground(Color.black);
		Managermode.setLocation(1400,30);
		Managermode.setFont(new Font("Helvetica",Font.BOLD,15));
		c.add(Managermode);
		
		Managermode.addActionListener(new ActionListener(){ //������ ������ Ŭ����
			public void actionPerformed(ActionEvent e){			
				String password=JOptionPane.showInputDialog("��й�ȣ �Է�"); //string�� ������ ���� �� ����
				while(true){
					if(password.equals("20130056"))
					{
						Manager manager=new Manager();
						manager.setVisible(true);
						setVisible(false);
						break;
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Ʋ�Ƚ��ϴ� �ٽ� �Է� �ϼ���","",JOptionPane.ERROR_MESSAGE);
						 break;
					}
					
				}
			}
		});
	
	for(int i=0;i<9;i++)
	{
		t[i]=new Table(i+1);
		t[i].setSize(280,160);
		t[i].setBackground(Color.green);
		t[i].setLayout(null);
		t[i].num.setLocation(120,5);
		t[i].Allmoney.setLocation(180,140);
		c.add(t[i]);
	}
	for(int i=0;i<9;i++){
		for(int j=0;j<8;j++)
		{
			t[i].TM[j]=new TablesMenu(MAIN.food[j].food_name);
		}
	}

	t[0].setLocation(430,150);
	t[1].setLocation(750, 150);
	t[2].setLocation(1070, 150);
	t[3].setLocation(430, 325);
	t[4].setLocation(750, 325);
	t[5].setLocation(1070, 325);
	t[6].setLocation(430, 500);
	t[7].setLocation(750, 500);
	t[8].setLocation(1070, 500);
	
	this.addWindowListener(new WindowAdapter()
	{
	    public void windowClosing(WindowEvent e)
	    {
	    	FileOutputStream f=null;

			try{
			BufferedWriter out=new BufferedWriter(new FileWriter("C:\\Users\\Babo\\workspace\\Soft2\\posmenu.txt"));
			
			out.write(Integer.toString(MAIN.menuamount)+"\n");
			
			for(int i=0;i<8;i++)
			{
				out.write(MAIN.food[i].food_name+"\n");
				out.write(Integer.toString(MAIN.food[i].food_price)+"\n");
				out.write(Integer.toString(MAIN.food[i].food_sales)+"\n");
			}
			
			out.write(Integer.toString(MAIN.allsales)+"\n");
			out.close();						
			}
			
			catch(IOException d)
			{
				System.out.println("��������� ����");
			}    
	    }
	});
	}
	
	public static int getnum(){
		FileReader fin = null;
		BufferedReader in = null;
		StringTokenizer st = null;
		int index = 0;
		try{
			fin = new FileReader("C:\\Users\\Babo\\workspace\\POSSYSTEM\\posmenu.txt");	 
			in = new BufferedReader(fin);	 
			st = new StringTokenizer(in.readLine());

			while (st.hasMoreTokens())  //�޸��忡�� ���� �ϳ��� ���� �������� �о store�� ����
			 {
				st.nextToken();
				 ++index;
			 }
		    	
			in.close();
		    }
		
		    catch (FileNotFoundException e)
		    {
			    System.out.println("���� ����");
		    }
		
		    catch (IOException e){
			   System.out.println("error");
		   }    
		return index/5;
}
}
